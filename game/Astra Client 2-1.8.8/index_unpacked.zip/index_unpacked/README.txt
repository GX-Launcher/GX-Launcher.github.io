index.html (EaglercraftX offline client) split apart:
src/00_launch_opts.js            eaglercraftXOpts (relays, container)
src/01_client_teavm.min.js       original compiled client (TeaVM, minified/obfuscated)
src/01_client_teavm.pretty.js    same, beautified
src/02_assets_loader_and_boot.js boot countdown + assetsURI loader (base64 stripped)
classnames.txt                   Java class-name strings found in the string pool
NOTE: TeaVM output cannot be turned back into Java; no symbol map is embedded.
Source: https://gitlab.com/lax1dude/eaglercraftx-1.8/
